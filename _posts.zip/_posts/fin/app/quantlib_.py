import QuantLib as ql

print(ql.__version__) 