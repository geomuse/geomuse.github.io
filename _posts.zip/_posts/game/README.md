---
title:  Python 游戏开发
author:   geo
---

| 项目 | 内容 | 状态 | 
| --- | --- | -- |
| 介绍 gym 环境 | 介绍gym环境 | ok 
| gym 游戏介绍 | 上面已经有了 | ok 
| 贪吃蛇的建立 | ok
| 贪吃蛇的建立 | ok
| 贪吃蛇的建立 | ok
| 封装成gym | ok
| 游戏变形: 心算游戏,多个奖励 | ok
| 介绍强化学习 Q-learning |
| DQN |
| 进一步的强化学习内容学习 |
| gym 训练AI |
| 建立AI 游戏 |
| 回接到gym环境 |

<!-- bundle exec jekyll serve -->

<!-- 如何创建价格函数就是一个目标

https://hrl.boyuai.com/chapter/1/%E5%88%9D%E6%8E%A2%E5%BC%BA%E5%8C%96%E5%AD%A6%E4%B9%A0

把其中观念整理好?

https://datawhalechina.github.io/easy-rl/#/chapter1/chapter1

看两本书整理重点. -->