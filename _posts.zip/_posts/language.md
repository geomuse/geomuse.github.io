2025-11-24
---

english | chinse
-- | --
four hours at the longest | 最多四个小时
fluffy | 蓬松的
bouillon | 肉汤
steamed | 蒸的
aftertaste | 余味
truffle and porcini | 松露和牛肝菌

2025-11-29
---

english | chinse
-- | --
regularly | 经常
dismiss | 驳斥
critique | 批判
trigger  |  扳机 
The smell of freshly baked bread always triggers memories of my grandmother. | 新鲜出炉的面包的香味总会让我想起我的祖母
stimulus | 刺激
enhance | 提高

2025-12-03
---

english | chinse
-- | --
proficiency | 熟练程度
moderate | 缓和
in a row | I've had to work late three nights in a row (连续)

2025-12-04
---

english | chinse
-- | --
Shelters | 庇护所
earthquake | 地震
shipping containers | 运输集装箱
solar panels | 太阳能电池板

2025-12-05
---

english | chinse
-- | --
Condos | 公寓 condominium
purchase | 购买
curb | 抑制
capital | 首都
wards | 区
proportion | 部分 , 比例

2025-12-08
---

english | chinse
-- | --
staple | 主食
condiment | 调味品

2025-12-19
---

english | chinse
-- | --
account for | 约占
curb | 抑制
particulate | 颗粒物
friction | 摩擦
levy | 征收
urge | 敦促
risen | 增长
preference | 偏好
advantages | 优势

2025-12-25
---

english | chinse
-- | --
depression | 沮丧
on average | 结果显示
workshop | 车间 ， 工作室
indigenous | 原住民

2025-12-29
---

english | chinse
-- | --
leftover | 剩菜
bacteria | 细菌
spoil | 变质