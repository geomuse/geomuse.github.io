---
layout: post
title:  金融学 选股机器人
date:   2025-08-24 09:01:00 +0800
image: 08.jpg
tags: 
    - python
    - financial
---

选股机器人

- 利用 `yfinance` 下载美股数据 
- `tidyquant` 包（封装了 quantmod，语法更现代）

利用 `r studio` 建立 `shiny` 平台

1. 下载股票的资讯
2. 信号处理
3. 画出图形

shiny 介绍
基本面
技术面
情绪面

实践整合